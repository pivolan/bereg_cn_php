tinyMCE.addI18n('gl.searchreplace_dlg',{
searchnext_desc:"Buscar outra vez",
notfound:"A busca rematou. No se atopou o texto buscado.",
search_title:"Buscar",
replace_title:"Buscar/Reemplazar",
allreplaced:"T\u00F3da-las coincidencias do texto buscado foron reemplazadas.",
findwhat:"Localizar",
replacewith:"Reemplazar por",
direction:"Direcci\u00F3n",
up:"Arriba",
down:"Abaixo",
mcase:"Min\u00FAs./Mai\u00FAs.",
findnext:"Buscar seginte",
replace:"Reemplazar",
replaceall:"Reemplazar todo"
});