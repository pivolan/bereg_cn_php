tinyMCE.addI18n('br.searchreplace_dlg',{
searchnext_desc:"Localizar novamente",
notfound:"A pesquisa foi conclu\u00EDda sem resultados.",
search_title:"Localizar",
replace_title:"Localizar/substituir",
allreplaced:"Todas as substitui\u00E7\u00F5es foram efetuadas.",
findwhat:"Localizar",
replacewith:"Substituir com",
direction:"Dire\u00E7\u00E3o",
up:"Acima",
down:"Abaixo",
mcase:"Diferenciar mai\u00FAsculas/min\u00FAsculas",
findnext:"Localizar pr\u00F3ximo",
replace:"Substituir",
replaceall:"Substituir todos"
});