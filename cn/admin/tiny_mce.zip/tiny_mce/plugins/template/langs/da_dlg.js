tinyMCE.addI18n('da.template_dlg',{
title:"Skabeloner",
label:"Skabelon",
desc_label:"Beskrivelse",
desc:"Inds\u00E6t pr\u00E6defineret skabelonindhold",
select:"V\u00E6lg en skabelon",
preview:"Vis udskrift",
warning:"Advarsel: Opdatering af en skabelon med en anden kan betyde datatab.",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Januar,Februar,Marts,April,Maj,Juni,Juli,August,September,Oktober,November,December",
months_short:"Jan,Feb,Mar,Apr,Maj,Jun,Jul,Aug,Sep,Okt,Nov,Dec",
day_long:"S\u00F8ndag,Mandag,Tirsdag,Onsdag,Torsdag,Fredag,L\u00F8rdag,S\u00F8ndag",
day_short:"S\u00F8n,Man,Tirs,Ons,Tors,Fre,L\u00F8r,S\u00F8n"
});