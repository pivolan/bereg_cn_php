tinyMCE.addI18n('sq.template_dlg',{
title:"Shabllonet",
label:"Shabllon",
desc_label:"P\u00EBrshkrimi",
desc:"Fut p\u00EBrmbajtje shabllon",
select:"Zgjidh nj\u00EB shabllon",
preview:"Paraqitje",
warning:"Kujdes: N\u00EBse rifreskoni nj\u00EB shabllon me nj\u00EB tjeter, mund t\u00EB humbisni t\u00EB dh\u00EBnat.",
mdate_format:"%d-%m-%Y %H:%M:%S",
cdate_format:"%d-%m-%Y %H:%M:%S",
months_long:"Janar,Shkurt,Mars,Prill,Maj,Qershor,Korrik,Gusht,Shtator,Tetor,N\u00EBntor,Dhjetor",
months_short:"Jan,Shk,Mar,Pri,Maj,Qer,Kor,Gus,Sht,Tet,N\u00EBn,Dhj",
day_long:"E Djel\u00EB,E H\u00EBn\u00EB,E Mart\u00EB,E M\u00EBrkur\u00EB,E Enjte,E Premte,E Shtun\u00EB,E Djel\u00EB",
day_short:"Dje,H\u00EBn,Mar,M\u00EBr,Enj,Pre,Sht,Dje"
});