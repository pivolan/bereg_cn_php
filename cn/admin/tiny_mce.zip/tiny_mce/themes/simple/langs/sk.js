tinyMCE.addI18n('sk.simple',{
bold_desc:"Tu\u010Dn\u00FD text (Ctrl+B)",
italic_desc:"\u0160ikm\u00FD text (kurziv\u00E1) (Ctrl+I)",
underline_desc:"Pod\u010Diarknut\u00FD text (Ctrl+U)",
striketrough_desc:"Pre\u0161krtnut\u00FD text",
bullist_desc:"Zoznam s odr\u00E1\u017Ekami",
numlist_desc:"\u010C\u00EDslovan\u00FD zoznam",
undo_desc:"Sp\u00E4\u0165 (Ctrl+Z)",
redo_desc:"Znovu (Ctrl+Y)",
cleanup_desc:"Vy\u010Disti\u0165 neupraven\u00FD k\u00F3d"
});