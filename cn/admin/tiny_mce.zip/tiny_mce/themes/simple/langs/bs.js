tinyMCE.addI18n('bs.simple',{
bold_desc:"Podebljaj (Ctrl+B)",
italic_desc:"Kurziv (Ctrl+I)",
underline_desc:"Podcrtaj (Ctrl+U)",
striketrough_desc:"Precrtaj",
bullist_desc:"Neure\u0111ena lista",
numlist_desc:"Ure\u0111ena lista",
undo_desc:"Poni\u0161ti (Ctrl+Z)",
redo_desc:"Ponovi (Ctrl+Y)",
cleanup_desc:"Po\u010Disti kod"
});