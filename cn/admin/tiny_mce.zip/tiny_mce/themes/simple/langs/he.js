tinyMCE.addI18n('he.simple',{
bold_desc:"\u05DE\u05D5\u05D3\u05D2\u05E9 (Ctrl+B)",
italic_desc:"\u05E0\u05D8\u05D5\u05D9 (Ctrl+I)",
underline_desc:"\u05E7\u05D5 \u05EA\u05D7\u05EA\u05D5\u05DF(Ctrl+U)",
striketrough_desc:"\u05E7\u05D5 \u05D7\u05D5\u05E6\u05D4",
bullist_desc:"\u05EA\u05D1\u05DC\u05D9\u05D8\u05D9\u05DD",
numlist_desc:"\u05DE\u05E1\u05E4\u05D5\u05E8",
undo_desc:"\u05D1\u05D8\u05DC \u05E4\u05E2\u05D5\u05DC\u05D4 (Ctrl+Z)",
redo_desc:"\u05D7\u05D6\u05D5\u05E8 \u05E4\u05E2\u05D5\u05DC\u05D4 (Ctrl+Y)",
cleanup_desc:"\u05E0\u05E7\u05D4 \u05E7\u05D5\u05D3"
});