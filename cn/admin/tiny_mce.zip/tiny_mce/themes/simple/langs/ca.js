tinyMCE.addI18n('ca.simple',{
bold_desc:"Negreta (Ctrl+B)",
italic_desc:"Cursiva (Ctrl+I)",
underline_desc:"Subratllat (Ctrl+U)",
striketrough_desc:"Tatxat",
bullist_desc:"Llista no ordenada",
numlist_desc:"Llista ordenada",
undo_desc:"Desf\u00E9s (Ctrl+Z)",
redo_desc:"Ref\u00E9s (Ctrl+Y)",
cleanup_desc:"Neteja el codi mal format"
});