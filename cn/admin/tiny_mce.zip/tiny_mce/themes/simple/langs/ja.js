tinyMCE.addI18n('ja.simple',{
bold_desc:"\u592A\u5B57 (Ctrl+B)",
italic_desc:"\u659C\u4F53 (Ctrl+I)",
underline_desc:"\u4E0B\u7DDA (Ctrl+U)",
striketrough_desc:"\u6253\u6D88\u3057\u7DDA",
bullist_desc:"\u756A\u53F7\u306A\u3057\u30EA\u30B9\u30C8",
numlist_desc:"\u756A\u53F7\u3064\u304D\u30EA\u30B9\u30C8",
undo_desc:"\u5143\u306B\u623B\u3059 (Ctrl+Z)",
redo_desc:"\u3084\u308A\u76F4\u3059 (Ctrl+Y)",
cleanup_desc:"\u30B3\u30FC\u30C9\u6574\u5F62"
});