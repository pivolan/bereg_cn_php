tinyMCE.addI18n('is.simple',{
bold_desc:"Feitletra (Ctrl+B)",
italic_desc:"Sk\u00E1letra (Ctrl+I)",
underline_desc:"Undirstrika (Ctrl+U)",
striketrough_desc:"Yfirstrika",
bullist_desc:"B\u00F3lulisti",
numlist_desc:"N\u00FAmera\u00F0ur listi",
undo_desc:"Taka til baka (Ctrl+Z)",
redo_desc:"Endurtaka (Ctrl+Y)",
cleanup_desc:"Hreinsa sk\u00EDtugan k\u00F3\u00F0a"
});