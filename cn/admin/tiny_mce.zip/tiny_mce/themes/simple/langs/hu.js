tinyMCE.addI18n('hu.simple',{
bold_desc:"F\u00E9lk\u00F6v\u00E9r (Ctrl+B)",
italic_desc:"D\u0151lt (Ctrl+I)",
underline_desc:"Al\u00E1h\u00FAzott (Ctrl+U)",
striketrough_desc:"\u00C1th\u00FAzott",
bullist_desc:"Felsorol\u00E1sos lista",
numlist_desc:"Sorrendezett lista",
undo_desc:"Visszavon (Ctrl+Z)",
redo_desc:"M\u00E9gis v\u00E9grehajt (Ctrl+Y)",
cleanup_desc:"Rendetlen k\u00F3d tiszt\u00EDt\u00E1sa"
});