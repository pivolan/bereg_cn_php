tinyMCE.addI18n('ii.simple',{
bold_desc:"\u7C97\u4F53 (Ctrl+B)",
italic_desc:"\u659C\u4F53 (Ctrl+I)",
underline_desc:"\u5E95\u7EBF (Ctrl+U)",
striketrough_desc:"\u5220\u9664\u7EBF",
bullist_desc:"\u9879\u76EE\u65B9\u5F0F\u5217\u8868",
numlist_desc:"\u7F16\u53F7\u65B9\u5F0F\u5217\u8868",
undo_desc:"\u8FD8\u539F (Ctrl+Z)",
redo_desc:"\u91CD\u590D (Ctrl+Y)",
cleanup_desc:"\u6E05\u9664\u5197\u4F59\u4EE3\u7801"
});