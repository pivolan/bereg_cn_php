tinyMCE.addI18n('vi.simple',{
bold_desc:"\u0110\u1EADm (Ctrl+B)",
italic_desc:"Nghi\u00EAng (Ctrl+I)",
underline_desc:"G\u1EA1ch ch\u00E2n (Ctrl+U)",
striketrough_desc:"G\u1EA1ch x\u00F3a",
bullist_desc:"Danh s\u00E1ch",
numlist_desc:"Danh s\u00E1ch th\u1EE9 t\u1EF1",
undo_desc:"Kh\u00F4i ph\u1EE5c (Ctrl+Z)",
redo_desc:"L\u1EB7p l\u1EA1i (Ctrl+Y)",
cleanup_desc:"D\u1ECDn d\u1EB9p m\u00E3 l\u1ED9n x\u1ED9n"
});