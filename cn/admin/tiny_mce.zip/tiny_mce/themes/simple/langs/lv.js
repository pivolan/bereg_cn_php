tinyMCE.addI18n('lv.simple',{
bold_desc:"Treknraksts (Ctrl+B)",
italic_desc:"Sl\u012Bpraksts (Ctrl+I)",
underline_desc:"Pasv\u012Btrojums (Ctrl+U)",
striketrough_desc:"P\u0101rsv\u012Btrojums",
bullist_desc:"Nenumur\u0113ts saraksts",
numlist_desc:"Numur\u0113ts saraksts",
undo_desc:"Atsaukt (Ctrl+Z)",
redo_desc:"Atatsaukt (Ctrl+Y)",
cleanup_desc:"Izt\u012Br\u012Bt nek\u0101rt\u012Bgu kodu"
});