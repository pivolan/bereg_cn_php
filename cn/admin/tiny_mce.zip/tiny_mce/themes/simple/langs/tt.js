tinyMCE.addI18n('tt.simple',{
bold_desc:"\u7C97\u9AD4(Ctrl+B)",
italic_desc:"\u659C\u9AD4(Ctrl+I)",
underline_desc:"\u5E95\u7DDA (Ctrl+U)",
striketrough_desc:"\u4E2D\u5283\u7DDA",
bullist_desc:"\u6E05\u55AE\u7B26\u865F",
numlist_desc:"\u7DE8\u865F",
undo_desc:"\u53D6\u6D88\u8B8A\u66F4 (Ctrl+Z)",
redo_desc:"\u91CD\u4F5C\u8B8A\u66F4 (Ctrl+Y)",
cleanup_desc:"\u6E05\u9664\u5167\u5BB9"
});