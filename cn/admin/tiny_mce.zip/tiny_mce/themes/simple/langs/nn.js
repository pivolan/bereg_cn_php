tinyMCE.addI18n('nn.simple',{
bold_desc:"Feit",
italic_desc:"Kursiv",
underline_desc:"Understreking",
striketrough_desc:"Gjennomstreking",
bullist_desc:"Punktliste",
numlist_desc:"Nummerliste",
undo_desc:"Angre",
redo_desc:"Gjer om",
cleanup_desc:"Rens grisete kode"
});