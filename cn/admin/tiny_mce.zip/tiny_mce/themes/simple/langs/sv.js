tinyMCE.addI18n('sv.simple',{
bold_desc:"Fet (Ctrl+B)",
italic_desc:"Kursiv (Ctrl+I)",
underline_desc:"Understruken (Ctrl+U)",
striketrough_desc:"Genomstruken",
bullist_desc:"Punktlista",
numlist_desc:"Nummerlista",
undo_desc:"\u00D6\u0085ngra (Ctrl+Z)",
redo_desc:"G\u00F6r om (Ctrl+Y)",
cleanup_desc:"St\u00E4da upp i k\u00E4llkoden"
});