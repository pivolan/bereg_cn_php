tinyMCE.addI18n('es.simple',{
bold_desc:"Negrita (Ctrl+B)",
italic_desc:"Cursiva (Ctrl+I)",
underline_desc:"Subrayado (Ctrl+U)",
striketrough_desc:"Tachado",
bullist_desc:"Lista desordenada",
numlist_desc:"Lista ordenada",
undo_desc:"Deshacer (Ctrl+Z)",
redo_desc:"Rehacer (Ctrl+Y)",
cleanup_desc:"Limpiar c\u00F3digo basura"
});