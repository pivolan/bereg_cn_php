tinyMCE.addI18n('zh.simple',{
bold_desc:"\u7C97\u4F53 (Ctrl+B)",
italic_desc:"\u659C\u4F53 (Ctrl+I)",
underline_desc:"\u4E0B\u5212\u7EBF (Ctrl+U)",
striketrough_desc:"\u5220\u9664\u7EBF",
bullist_desc:"\u9879\u76EE\u5217\u8868",
numlist_desc:"\u7F16\u53F7\u5217\u8868",
undo_desc:"\u64A4\u9500 (Ctrl+Z)",
redo_desc:"\u91CD\u505A (Ctrl+Y)",
cleanup_desc:"\u6E05\u7406\u4EE3\u7801"
});