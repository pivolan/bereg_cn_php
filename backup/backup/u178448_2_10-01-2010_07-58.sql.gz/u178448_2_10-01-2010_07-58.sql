#SKD101|u178448_2|9|2010.01.10 07:58:54|5|3|2

DROP TABLE IF EXISTS `Article`;
CREATE TABLE `Article` (
  `id` int(11) NOT NULL auto_increment,
  `active` enum('on','off') /*!40101 collate utf8_unicode_ci */ default 'on',
  `date` int(11) default NULL,
  `login` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `name` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `icon` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `title` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `category` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `subcat` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `parent` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL auto_increment,
  `active` enum('on','off') /*!40101 collate utf8_unicode_ci */ default 'on',
  `date` int(11) default NULL,
  `icon` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `name` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `title` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `parent` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 collate utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `content`;
CREATE TABLE `content` (
  `id` int(11) NOT NULL auto_increment,
  `active` enum('0','1') /*!40101 collate utf8_unicode_ci */ default '0',
  `date` int(11) default NULL,
  `createdby` int(11) default '0',
  `name` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `icon` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `title` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `parent` int(11) default '0',
  `parents` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `childs` int(11) default '0',
  `folder` enum('0','1') /*!40101 collate utf8_unicode_ci */ default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `linkleft`;
CREATE TABLE `linkleft` (
  `id` int(11) NOT NULL auto_increment,
  `active` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `pageid` tinyint(4) default NULL,
  `url` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `name` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `number` int(11) default NULL,
  `position` enum('left','top') /*!40101 collate utf8_unicode_ci */ default 'left',
  `folder` enum('0','1') /*!40101 collate utf8_unicode_ci */ default '0',
  `text` text /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `title` varchar(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `linkleft` VALUES
(1, 'ON', 0, '', 'services', 100, 'top', '0', '', '服务'),
(2, 'ON', 0, '', 'main', 201, 'left', '0', '', '家'),
(3, 'ON', 0, '/forum/', '0', 302, 'left', '0', '', '论坛');

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(11) NOT NULL auto_increment,
  `date` int(11) default NULL,
  `title` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `login` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL auto_increment,
  `title` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `text` text /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `parent` int(11) default '0',
  `userid` int(11) default NULL,
  `date` int(11) default NULL,
  `trace` enum('in','out') /*!40101 collate utf8_unicode_ci */ default 'out',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL auto_increment,
  `title` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `text` text /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `login` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `name` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `date` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `pages` VALUES
(1, '服务', '俄罗斯 依日沃斯克OOO《BEREG》公司为俄罗斯的企业和中国的企业提供以下种类的服务：<br/>\r\n——从中国寻找和提供商品；<br/>\r\n在中国寻找必需的商品——提供关于商品的信息——在网站上具有的商品的图片，如果客户必需的商品在网站上没有，就根据客户商品的清单进行必要的工作——前往企业，准备寄发商品样品。<br/>\r\n在2—5天内确定这项服务的价格，并同客户协商。将来按具体合同实现为客户提供必需的商品。<br/>\r\n——在中国寻找设备；<br/>\r\n按客户要求为他提供他所必需的设备的信息（如果在网站有此信息，则免费提供）——设备图片，基本技术性质，设备出厂价格。如果客户所必需的设备在网站上没有，按照客户的清单进行必要的工作——前往企业，为客户寄发图片产品目录和录像资料。<br/>在2—5天内确定此项工作的价格，并同客户协商。往后按具体合同为客户实现提供必需的设备。<br/>\r\n——用俄文、中文准备提供必需货物和设备的合同；<br/>\r\n用俄文、中文完成为客户提供必需的商品和设备的合同的准备。此项服务的价格为合同金额的2％-5％，但不少于500美元。<br/>\r\n——跟随合同，在依日沃斯克接货，货物的清关；<br/>\r\n除合同的准备，我们还实现在依日沃斯克货物的跟踪，接货和清关。在必要时，可以另签合同把清关后的货物送到客户。服务价格另行协商。<br/>\r\n——用俄文、中文分布寻找网址信息；<br/>\r\n这项服务就是在中国寻找网址上用中文介绍俄罗斯企业的信息，在俄罗斯寻找的网址上用俄文介绍中国企业的信息。在网站上发布的信息要适合客户的生产行业。在2-5个网址上寻找的信息发布量达到300个俄文字母，60个中文字，服务价格为100美元。<br/>\r\n——中文网址翻译成俄文；<br/>\r\n建议为中国的企业家用俄文办理他们的网址（全部或部分），以便允许他们进入俄罗斯网站——关于你们企业的信息，网站的所有俄罗斯使用者都能获得。服务的价格，起价为300美元，具体价格按具体工作量协商而定。<br/>\r\n——中国产品目录翻译成俄文；<br/>\r\n建议为中国企业产品做出俄文目录。服务价格要根据目录的大小，具备的样本而定。<br/>\r\n——准备俄文的广告材料（宣传单，样本）；<br/>\r\n建议为中国企业准备俄文的广告材料（宣传单，样本）。双面广告，宣传单，A4—200美元。<br/>\r\n——组织中国企业参加俄罗斯专题展览会；<br/>\r\n这项服务就是建议组织中国的企业（面授或函授）参加专题的俄罗斯区域或国际展览会。<br/>我们将为中国企业家在专题展览会上的商品和设备在俄罗斯扩大销售提供协助。收集信息和疏理信息，服务价格按每次展会具体商妥。<br/>\r\n——参加在中国的展览会；<br/>\r\n根据俄罗斯客户的要求我们可以组织他们参观在中国的专题展览会。并提供熟练的翻译。同时，可能为客户从具体的展览会收集专题信息—设备和商品的具体信息，让这种信息也可以在俄罗斯获得。<br/>\r\n服务的价格每次按具体情况商妥。<br/>\r\n尊敬的先生们！<br/>\r\n如果在上述建议的服务项目中，您没找到您要求的服务，请您通知您所需要的，我们一定努力帮助您。<br/>\r\n\r\n', 'Admin', 'services', 1258232400),
(2, '家', '<b>家</b><br/><br/>\r\n     中国现如今是世界上发展速度最快的国家。中国的文化，中国的人的勤劳以及国家为发展贸易所创造的条件，这一切都是中国经济迅速发展的实际因素。<br/><br/>\r\n\r\n     我们公司自2002年起开始同中国企业合作。在这期间，我们学会了签署设备和商品的供应合同，并且以合理的方式来履行这些合同。在这期间，我们在中国也积累了大量可靠的合作伙伴，以及在翻译、工程师和工艺师等方面高水平的专家。<br/><br/>\r\n\r\n     我们曾经供应并且今后还将供应中国的设备—热塑机械，挤压机，实验机械等等；所有的这些机械都在我们的订购企业那里正常的运转。<br/><br/>\r\n\r\n     今天我们准备促进中俄两国企业贸易的发展，为在中国寻找必要的商品和设备提供服务，提供翻译服务，提供关于中国企业的信息，以及关于在中国生产的产品和设备的信息。<br/><br/>\r\n\r\n     我们相信，我们掌握的知识和信息，能够帮助中俄两国的企业，成功的发展相互之间的合作。<br/><br/>', 'Admin', 'main', 1258232400);

DROP TABLE IF EXISTS `subcat`;
CREATE TABLE `subcat` (
  `id` int(11) NOT NULL auto_increment,
  `active` enum('on','off') /*!40101 collate utf8_unicode_ci */ default 'on',
  `date` int(11) default NULL,
  `icon` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `name` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `title` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `parent` char(255) /*!40101 collate utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 collate utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `login` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `pass` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `fio` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `name` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `sername` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `lastname` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `status` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `email` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `date` int(11) default NULL,
  `birthdate` int(11) default NULL,
  `adress` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `company` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  `tel` char(255) /*!40101 collate utf8_unicode_ci */ default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

